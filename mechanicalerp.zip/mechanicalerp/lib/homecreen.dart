import 'package:flutter/material.dart';
class Homeui extends StatefulWidget {
  const Homeui({super.key});

  @override
  State<Homeui> createState() => _HomeuiState();
}

class _HomeuiState extends State<Homeui> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        backgroundColor: Colors.white,
        appBar: AppBar(
          elevation: 0,
          //brightness: Brightness.light,
          backgroundColor: Colors.white,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(Icons.arrow_back_ios,
              size: 10,
              color: Colors.black,),
            // MediaQuery.of(context).size.height

          ),
        ),

        body: SingleChildScrollView(
        child: Padding(
        padding: const EdgeInsets.all(16.0),
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
    TextField(
    decoration: InputDecoration(labelText: 'Logout'),
    ),
    ],
    ),
    ),
    ),
    );


  }
}
